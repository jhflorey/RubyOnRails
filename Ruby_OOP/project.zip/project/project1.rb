require_relative 'project'
class Project1 < Project
	def name
		puts 'Python'
	end
	def elevator_pitch
		puts ' a high-level programming language used for general-purpose programming'
	end
end
project1 = Project.new("Project_1 ", "Description_1")
project1.name 
project1.elevator_pitch